export class Templates
{
    sub_title:string;
    client_subject:string;
    client_body:string;
    user_id:string;    
}