export class ClientEmailTemplate
{
    id: number;
    sub_title: string;
    client_subject: string;    
    client_body: string;   
    user_id: number;    
}
