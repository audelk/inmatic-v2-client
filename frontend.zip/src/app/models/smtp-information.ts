export class SmtpInformation
{
    id: number;
    host: string;
    port: number;    
    username: string;
    password: string;
    user_id: number;
    
}
