// export const API_URL = '';
// export const API_URL = 'http://api.likedinsolutionv2.com';
export const API_URL = 'http://3.15.4.53/backendv2';
